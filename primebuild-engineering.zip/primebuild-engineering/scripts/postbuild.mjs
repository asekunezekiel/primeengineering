/**
 * Runs after `vite build`.
 * 1. Replaces the __SITE_URL__ token in the built HTML.
 * 2. Writes a route-specific copy of the HTML for /contact so crawlers see correct metadata.
 * 3. Writes sitemap.xml and robots.txt for the deployment URL.
 *
 * Site URL order: SITE_URL, then VERCEL_PROJECT_PRODUCTION_URL, then a local placeholder.
 */
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const dist = new URL("../dist/", import.meta.url).pathname;

let site = process.env.SITE_URL?.trim();
if (!site && process.env.VERCEL_PROJECT_PRODUCTION_URL) site = `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`;
if (!site) {
  site = "http://localhost:4173";
  console.warn("[postbuild] SITE_URL is not set. Using http://localhost:4173. Set SITE_URL before deploying.");
}
site = site.replace(/\/+$/, "");

const esc = (s) => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");

const base = readFileSync(join(dist, "index.html"), "utf8").replaceAll("__SITE_URL__", site);
writeFileSync(join(dist, "index.html"), base);

const contact = {
  title: "Start Your Project | PrimeBuild Engineering",
  description:
    "Send a project inquiry to PrimeBuild Engineering. Share your location, project type, services needed, and timeline for eligible U.S. projects.",
  path: "/contact",
};

let page = base;
page = page.replace(/<title>[\s\S]*?<\/title>/, `<title>${esc(contact.title)}</title>`);
page = page.replace(/(<meta\s+name="description"\s+content=")[^"]*(")/, `$1${esc(contact.description)}$2`);
page = page.replace(/(<meta\s+property="og:title"\s+content=")[^"]*(")/, `$1${esc(contact.title)}$2`);
page = page.replace(/(<meta\s+property="og:description"\s+content=")[^"]*(")/, `$1${esc(contact.description)}$2`);
page = page.replace(/(<meta\s+name="twitter:title"\s+content=")[^"]*(")/, `$1${esc(contact.title)}$2`);
page = page.replace(/(<meta\s+name="twitter:description"\s+content=")[^"]*(")/, `$1${esc(contact.description)}$2`);
page = page.replace(/(<link\s+rel="canonical"\s+href=")[^"]*(")/, `$1${site}${contact.path}$2`);
page = page.replace(/(<meta\s+property="og:url"\s+content=")[^"]*(")/, `$1${site}${contact.path}$2`);

mkdirSync(join(dist, "contact"), { recursive: true });
writeFileSync(join(dist, "contact", "index.html"), page);

const today = new Date().toISOString().slice(0, 10);
const urls = ["/", "/contact"];
writeFileSync(
  join(dist, "sitemap.xml"),
  `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls
    .map((u) => `  <url><loc>${site}${u === "/" ? "/" : u}</loc><lastmod>${today}</lastmod></url>`)
    .join("\n")}\n</urlset>\n`,
);
writeFileSync(join(dist, "robots.txt"), `User-agent: *\nAllow: /\nDisallow: /api/\n\nSitemap: ${site}/sitemap.xml\n`);

console.log(`[postbuild] site URL ${site}; wrote contact/index.html, sitemap.xml, robots.txt`);
