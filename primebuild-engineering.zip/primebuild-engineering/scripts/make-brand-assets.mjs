/**
 * Generates og-image.png, favicon-32.png and apple-touch-icon.png into /public.
 * Text is converted to outlines with opentype.js so no system fonts are needed.
 * Run: node scripts/make-brand-assets.mjs
 */
import { readFileSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import sharp from "sharp";
import opentype from "opentype.js";

const require = createRequire(import.meta.url);
const soraPath = require.resolve("@fontsource/sora/files/sora-latin-600-normal.woff");
const interPath = require.resolve("@fontsource/inter/files/inter-latin-500-normal.woff");
const toBuf = (p) => {
  const b = readFileSync(p);
  return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);
};
const sora = opentype.parse(toBuf(soraPath));
const inter = opentype.parse(toBuf(interPath));

// Per-glyph layout. This skips opentype.js text shaping, which fails on some GSUB lookups.
const text = (font, str, x, y, size, fill, spacing = 0) => {
  const scale = size / font.unitsPerEm;
  let cx = x;
  let out = "";
  for (const ch of str) {
    const g = font.charToGlyph(ch);
    out += `<path fill="${fill}" d="${g.getPath(cx, y, size).toPathData(2)}"/>`;
    cx += g.advanceWidth * scale + spacing;
  }
  return out;
};

const og = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
<rect width="1200" height="630" fill="#080F12"/>
${[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((i) => `<line x1="${60 + i * 90}" x2="${60 + i * 90}" y1="0" y2="630" stroke="#FAF9F6" stroke-opacity="0.06"/>`).join("")}
${text(sora, "PrimeBuild", 60, 100, 44, "#FAF9F6")}
${text(inter, "ENGINEERING", 60, 128, 13, "#FAF9F6", 7.2)}
${text(sora, "Engineering", 60, 330, 124, "#FAF9F6")}
${text(sora, "for what’s next.", 60, 456, 124, "#FAF9F6")}
<rect x="60" y="520" width="56" height="6" fill="#D7FF4F"/>
${text(inter, "Structural, civil, building and MEP engineering support.", 60, 574, 28, "#9FABAA")}
</svg>`;
await sharp(Buffer.from(og)).png().toFile("public/og-image.png");

const fav = readFileSync("public/favicon.svg");
await sharp(fav).resize(32, 32).png().toFile("public/favicon-32.png");
await sharp(fav).resize(180, 180).png().toFile("public/apple-touch-icon.png");
console.log("Brand assets written to /public");
