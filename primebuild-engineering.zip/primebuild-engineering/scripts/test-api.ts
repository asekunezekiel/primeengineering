/* Local test for api/inquiry.ts with a mocked fetch. Run: npm run test:api */
import handler from "../api/inquiry.ts";

type Result = { status: number; body: any };

function call(body: unknown, headers: Record<string, string> = {}, ip = "1.1.1.1"): Promise<Result> {
  return new Promise((resolve) => {
    let status = 200;
    const res = {
      status(c: number) { status = c; return res; },
      json(b: unknown) { resolve({ status, body: b }); },
      setHeader() {},
    };
    void handler(
      { method: "POST", headers: { host: "localhost", "x-forwarded-for": ip, ...headers }, body },
      res,
    );
  });
}

const valid = {
  name: "Alex Rivera",
  email: "alex@example.com",
  company: "",
  city: "Sacramento",
  state: "CA",
  projectType: "adu",
  services: ["structural", "mep-energy"],
  description: "Detached ADU of about 800 sq ft. Need structural calcs and Title 24 documents.",
  timeline: "2-4-weeks",
  consent: true,
  website: "",
  startedAt: Date.now() - 20000,
  turnstileToken: "",
};

let sent: any[] = [];
let resendStatus = 200;
globalThis.fetch = (async (url: any, init: any) => {
  const u = String(url);
  if (u.includes("resend.com")) {
    sent.push(JSON.parse(init.body));
    return new Response(resendStatus === 200 ? '{"id":"abc"}' : "denied", { status: resendStatus });
  }
  if (u.includes("turnstile")) {
    const ok = String(init.body).includes("response=good");
    return new Response(JSON.stringify({ success: ok }), { status: 200 });
  }
  throw new Error("unexpected fetch " + u);
}) as typeof fetch;

let failures = 0;
function check(name: string, cond: boolean, extra?: unknown) {
  if (!cond) failures++;
  console.log(`${cond ? "PASS" : "FAIL"}  ${name}${cond ? "" : "  " + JSON.stringify(extra)}`);
}

delete process.env.RESEND_API_KEY;
delete process.env.INQUIRY_FROM_EMAIL;
delete process.env.TURNSTILE_SECRET_KEY;

let r = await call({ ...valid, email: "nope", consent: false }, {}, "2.2.2.1");
check("rejects invalid input with field errors", r.status === 400 && !!r.body.errors?.email && !!r.body.errors?.consent, r);

r = await call(valid, {}, "2.2.2.2");
check("returns 503, not success, when email is not configured", r.status === 503 && r.body.ok === false, r);

process.env.RESEND_API_KEY = "re_test";
process.env.INQUIRY_FROM_EMAIL = "PrimeBuild <inquiries@example.com>";

r = await call({ ...valid, website: "http://spam.example" }, {}, "2.2.2.3");
check("silently drops honeypot hits without sending", r.status === 200 && sent.length === 0, { r, sent: sent.length });

r = await call({ ...valid, startedAt: Date.now() - 200 }, {}, "2.2.2.4");
check("rejects instant submissions", r.status === 400 && r.body.code === "too_fast", r);

r = await call(valid, { origin: "https://evil.example" }, "2.2.2.5");
check("rejects cross-origin requests", r.status === 403, r);

r = await call({ ...valid, name: "<script>alert(1)</script>" }, { origin: "http://localhost" }, "2.2.2.6");
const html = sent[0]?.html as string | undefined;
check(
  "delivers valid inquiry, escapes HTML, sets reply_to and recipient",
  r.status === 200 && r.body.ok === true && sent.length === 1 &&
    !!html && !html.includes("<script>") && sent[0].reply_to === "alex@example.com" &&
    sent[0].to[0] === "proengineers.team@gmail.com",
  { r, to: sent[0]?.to },
);

resendStatus = 500;
r = await call(valid, {}, "2.2.2.7");
check("returns 502, not success, when the email provider fails", r.status === 502 && r.body.ok === false, r);
resendStatus = 200;

process.env.TURNSTILE_SECRET_KEY = "secret";
r = await call({ ...valid, turnstileToken: "bad" }, {}, "2.2.2.8");
check("rejects a failed captcha", r.status === 400 && r.body.code === "captcha", r);
sent = [];
r = await call({ ...valid, turnstileToken: "good" }, {}, "2.2.2.9");
check("accepts a passed captcha", r.status === 200 && sent.length === 1, r);

for (let i = 0; i < 6; i++) r = await call(valid, {}, "3.3.3.3");
check("rate limits repeated submissions", r.status === 429, r);

console.log(failures === 0 ? "\nAll API checks passed." : `\n${failures} check(s) failed.`);
process.exit(failures === 0 ? 0 : 1);
