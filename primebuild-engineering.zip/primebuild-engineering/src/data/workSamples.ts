/**
 * Work samples shown on the homepage.
 *
 * - kind "sample": a generated illustration. Always shown with a "Sample graphic" label.
 * - kind "project": a real drawing or detail. TypeScript requires `permission` to be filled in so
 *   nothing is published without a recorded right to show it. Place images in /public/images/work.
 */
export type SampleGraphicKey = "framing" | "detail" | "site";

export type WorkSample =
  | { kind: "sample"; id: string; title: string; caption: string; graphic: SampleGraphicKey }
  | {
      kind: "project";
      id: string;
      title: string;
      caption: string;
      image: { src: string; alt: string; width: number; height: number };
      permission: string; // e.g. "Client approved on 2026-03-01"
    };

export const WORK_SAMPLES: WorkSample[] = [
  {
    kind: "sample",
    id: "framing",
    title: "Floor framing plan",
    caption: "A framing plan shows where joists, beams and posts sit, so a builder and a reviewer can read the same layout.",
    graphic: "framing",
  },
  {
    kind: "sample",
    id: "detail",
    title: "Connection detail",
    caption: "A detail zooms in on one connection, such as how a wall is anchored to its foundation.",
    graphic: "detail",
  },
  {
    kind: "sample",
    id: "site",
    title: "Site and drainage plan",
    caption: "A site plan shows the property, the building and the direction water should flow.",
    graphic: "site",
  },
];
