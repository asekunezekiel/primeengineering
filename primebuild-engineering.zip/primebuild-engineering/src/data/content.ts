export type ServiceKey = "structural" | "civil" | "permit-plans" | "mep-energy";

export const SERVICES_CONTENT: {
  key: ServiceKey;
  name: string;
  summary: string;
  scope: string[];
  note?: string;
}[] = [
  {
    key: "structural",
    name: "Structural Engineering",
    summary:
      "Engineering that shows how a building carries its loads, then documents it in a form a plan reviewer can follow.",
    scope: [
      "Structural calculations",
      "Foundation and framing design support",
      "Beam and column analysis",
      "Load calculations",
      "Structural details",
      "Permit documentation",
    ],
  },
  {
    key: "civil",
    name: "Civil and Site Engineering",
    summary: "Plans that manage how water and earth move across a property, prepared for the agencies that review them.",
    scope: [
      "Grading plans",
      "Drainage design",
      "Stormwater documentation",
      "Site plans",
      "Related civil deliverables where applicable",
    ],
    note: "Civil requirements vary widely by city and county. We confirm what your jurisdiction expects before scoping the work.",
  },
  {
    key: "permit-plans",
    name: "Building and Permit Plans",
    summary:
      "Clear drawings and coordination for residential and light-commercial projects heading into permit review.",
    scope: [
      "ADUs",
      "Garage conversions",
      "Additions",
      "Permit drawing coordination",
      "Plan-check correction support",
    ],
  },
  {
    key: "mep-energy",
    name: "MEP and Energy Compliance",
    summary:
      "Heating and cooling design documents, plus the energy reports many permits require. Ask us if your project also needs electrical or plumbing coordination.",
    scope: [
      "HVAC design documentation",
      "Heating and cooling load calculations",
      "Duct sizing",
      "Mechanical permit plans",
      "Title 24, COMcheck and REScheck documentation where relevant",
    ],
  },
];

export const AUDIENCES: {
  id: string;
  label: string;
  intro: string;
  needs: string[];
  starts: ServiceKey[];
}[] = [
  {
    id: "owners",
    label: "Homeowners and property owners",
    intro: "You know what you want to build. You may not know which documents the building department will ask for.",
    needs: [
      "A permit set for an ADU, garage conversion or addition",
      "Structural support for a remodel that changes walls or loads",
      "Help responding to plan-check comments",
    ],
    starts: ["permit-plans", "structural"],
  },
  {
    id: "builders",
    label: "Builders and contractors",
    intro: "A job is waiting on a document, and the schedule does not move.",
    needs: [
      "Structural or mechanical documents to keep a permit moving",
      "Revised details after a field change",
      "Energy compliance reports before final inspection",
    ],
    starts: ["structural", "mep-energy"],
  },
  {
    id: "architects",
    label: "Architects and designers",
    intro: "Your drawings are set. The engineering needs to match them.",
    needs: [
      "Structural and mechanical coordination with your plan set",
      "Calculations and details that follow your design intent",
      "Energy documentation for submittal",
    ],
    starts: ["structural", "mep-energy"],
  },
  {
    id: "developers",
    label: "Developers",
    intro: "You are managing scope across sites, units or phases.",
    needs: [
      "Grading and drainage plans for sites with water to manage",
      "Consistent documentation across similar units",
      "Coordinated sets across disciplines",
    ],
    starts: ["civil", "permit-plans"],
  },
  {
    id: "firms",
    label: "Engineering firms",
    intro: "You need capacity or a specialty without adding staff.",
    needs: [
      "Support on calculations and documentation",
      "Specialty items such as load calculations and energy compliance",
      "Help with plan-check responses",
    ],
    starts: ["mep-energy", "structural"],
  },
];

export const PROJECT_TYPES_CONTENT: {
  value: string;
  name: string;
  description: string;
  often: string;
}[] = [
  { value: "adu", name: "ADUs and guest houses", description: "Detached, attached or converted living space on an existing lot.", often: "Permit plans, structural, energy compliance" },
  { value: "garage-conversion", name: "Garage conversions", description: "Turning a garage into habitable space, including the framing and energy changes that come with it.", often: "Permit plans, structural, energy compliance" },
  { value: "addition", name: "Additions and remodels", description: "New rooms, second stories, and changes to walls that carry load.", often: "Structural, permit plans" },
  { value: "new-home", name: "New single-family homes", description: "Engineering support for new residential construction.", often: "Structural, civil, energy compliance" },
  { value: "light-commercial", name: "Light-commercial and tenant improvements", description: "Smaller commercial spaces, build-outs and renovations.", often: "Permit plans, mechanical, energy compliance" },
  { value: "site-work", name: "Site work, grading and drainage", description: "Lots that need grading, runoff control or stormwater documentation.", often: "Civil" },
  { value: "mechanical-energy", name: "Mechanical and energy compliance", description: "Load calculations, duct sizing and energy reports for a project that already has a design.", often: "MEP and energy compliance" },
  { value: "plan-check", name: "Plan-check corrections", description: "You have reviewer comments and need help answering them.", often: "Depends on the comments" },
];

export const DELIVERABLES: { name: string; what: string; service: string }[] = [
  { name: "Structural calculations", what: "Written calculations showing that members and connections are sized for the loads on the project.", service: "Structural" },
  { name: "Foundation and framing plans", what: "Drawings of footings, beams, columns and framing layout.", service: "Structural" },
  { name: "Structural detail sheets", what: "Close-up drawings of connections and assemblies for builders and plan reviewers.", service: "Structural" },
  { name: "Grading and drainage plans", what: "How the site slopes and where water is directed.", service: "Civil" },
  { name: "Stormwater documentation", what: "Reports or forms required where local rules manage runoff.", service: "Civil" },
  { name: "Permit plan set", what: "Coordinated drawings prepared for building department submittal.", service: "Permit plans" },
  { name: "Plan-check response package", what: "Revised sheets and written responses to reviewer comments.", service: "Permit plans" },
  { name: "Heating and cooling load calculations", what: "The sizing basis for HVAC equipment, often called Manual J.", service: "MEP and energy" },
  { name: "Duct sizing", what: "Sizes and layout for duct runs, often called Manual D.", service: "MEP and energy" },
  { name: "Energy compliance reports", what: "Title 24, COMcheck or REScheck documents where your jurisdiction requires them.", service: "MEP and energy" },
];

export const PRINCIPLES: { title: string; body: string }[] = [
  { title: "Scope you can read", body: "We define what is included, what is not, and what we need from you before work begins." },
  { title: "Documents that agree", body: "Calculations, drawings and reports are checked against each other so the set reads as one package." },
  { title: "Plain language", body: "You get a clear explanation of what each document does and why a building department asks for it." },
  { title: "Honest about limits", body: "If a service is not available in your state, or a project needs a different professional, we say so early." },
];

export const PROCESS: { title: string; body: string }[] = [
  { title: "Send your project details", body: "Use the inquiry form to describe the project, its location and your timeline." },
  { title: "We review scope and eligibility", body: "We look at what you need, your jurisdiction, and whether we can provide it, including any stamping requirements." },
  { title: "Confirm the scope", body: "You receive a clear scope of work before engineering starts." },
  { title: "Engineering and coordination", body: "We prepare calculations, drawings and reports, and coordinate them into one set." },
  { title: "Delivery and plan-check support", body: "You receive documents prepared for submittal. If the reviewer comments, we help with corrections within the agreed scope." },
];

export const FAQS: { q: string; a: string }[] = [
  {
    q: "Can PrimeBuild stamp and sign my plans or calculations?",
    a: "It depends. Engineering stamps, signed calculations and sealed plans depend on your project's scope, its jurisdiction, applicable licensing, and confirmation by an appropriately licensed professional. We tell you what is possible for your project before any scope is agreed.",
  },
  {
    q: "Which states do you work in?",
    a: "Our work is focused on U.S. projects, but we do not offer every service in every state. Tell us the project location in your inquiry and we will confirm what is available.",
  },
  {
    q: "Can you guarantee my permit will be approved?",
    a: "No one can. The local building department decides. We prepare clear, coordinated documentation and help respond to plan-check comments within the agreed scope.",
  },
  {
    q: "What should I include in my inquiry?",
    a: "The project location, what you want to build or change, which services you think you need, and your target date. If you have drawings, a survey or reviewer comments, mention them. We will explain how to share files after we reply.",
  },
  {
    q: "How long will it take?",
    a: "It depends on scope, jurisdiction and how complete your information is. After we review your inquiry, we will give you a realistic timeline.",
  },
  {
    q: "Do you work with architects, builders and other firms?",
    a: "Yes. Many projects involve a design team and a builder, and we write documents so each party can use them. Engineering firms can also ask about project support.",
  },
  {
    q: "What are Title 24, COMcheck and REScheck?",
    a: "Title 24 is California's building energy code. COMcheck and REScheck are U.S. Department of Energy tools used to show that commercial and residential projects meet model energy codes. Which one applies depends on your location and project type.",
  },
  {
    q: "What if the building department sends corrections?",
    a: "Send us the comments. We can help respond to comments on documents we prepared. Whether we can help with documents prepared by others depends on scope and licensing, and we will tell you plainly.",
  },
  {
    q: "How is pricing handled?",
    a: "Fees depend on the scope. After reviewing your inquiry, we share a scope and a quote before work begins.",
  },
];
