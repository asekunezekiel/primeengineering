import { useDocumentMeta } from "../hooks/useDocumentMeta";
import { Button } from "../components/Button";
import { ROUTES } from "../lib/site";

export function NotFound() {
  useDocumentMeta({
    title: "Page not found | PrimeBuild Engineering",
    description: "This page does not exist. Return to the PrimeBuild Engineering homepage.",
    path: "/",
  });
  return (
    <section aria-labelledby="nf-title" className="theme-dark flex min-h-[70vh] items-center pb-20 pt-40">
      <div className="wrap">
        <h1 id="nf-title" className="h-section">
          That page does not exist.
        </h1>
        <p className="lede text-muted mt-5">The link may be old or mistyped.</p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Button to={ROUTES.home}>Go to the homepage</Button>
          <Button to={ROUTES.contact} variant="secondary">
            Start Your Project
          </Button>
        </div>
      </div>
    </section>
  );
}
