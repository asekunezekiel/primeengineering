import { useDocumentMeta } from "../hooks/useDocumentMeta";
import { InquiryForm } from "../components/InquiryForm";
import { SITE } from "../lib/site";

export const CONTACT_META = {
  title: "Start Your Project | PrimeBuild Engineering",
  description:
    "Send a project inquiry to PrimeBuild Engineering. Share your location, project type, services needed, and timeline for eligible U.S. projects.",
  path: "/contact",
};

const NEXT = [
  "We review your project details, location and timeline.",
  "We confirm whether the services you need are available for your project and jurisdiction.",
  "We reply by email with questions or a proposed scope.",
];

export function Contact() {
  useDocumentMeta(CONTACT_META);
  return (
    <>
      <section aria-labelledby="contact-title" className="theme-dark relative overflow-hidden pb-16 pt-[8.5rem] md:pb-24 md:pt-[10.5rem]">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0">
          <div className="wrap grid h-full grid-cols-4 md:grid-cols-12">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className={`border-l border-paper/[0.06] ${i >= 4 ? "hidden md:block" : ""} ${i === 11 ? "border-r" : ""}`} />
            ))}
          </div>
        </div>
        <div className="wrap relative grid gap-8 md:grid-cols-12 md:gap-x-6">
          <h1 id="contact-title" className="h-display md:col-span-9" style={{ fontSize: "clamp(2.8rem, 7vw, 6.4rem)" }}>
            Tell us about your project.
          </h1>
          <p className="lede text-paper/85 md:col-span-6">
            The more detail you share, the faster we can tell you what is possible and what to expect next.
          </p>
        </div>
      </section>

      <section aria-label="Inquiry form and details" className="theme-light section !pt-16 md:!pt-24">
        <div className="wrap grid gap-14 lg:grid-cols-12 lg:gap-x-12">
          <div className="lg:col-span-7 lg:order-2">
            <InquiryForm />
          </div>

          <aside className="space-y-12 lg:col-span-5 lg:order-1">
            <div className="lg:sticky lg:top-28">
              <h2 className="h-item">What happens next</h2>
              <ol className="mt-5 space-y-4">
                {NEXT.map((t, i) => (
                  <li key={t} className="rule-t flex gap-4 pt-4">
                    <span aria-hidden="true" className="font-display font-semibold">
                      {i + 1}
                    </span>
                    <span>{t}</span>
                  </li>
                ))}
              </ol>

              <h2 className="h-item mt-12">Prefer email?</h2>
              <p className="mt-3">
                <a href={`mailto:${SITE.email}`} className="link-line break-all font-semibold">
                  {SITE.email}
                </a>
              </p>

              <h2 className="h-item mt-12">Your details</h2>
              <p className="small text-muted mt-3">
                We use what you send only to review your project and reply to you. Please do not include passwords, payment
                details or government ID numbers. This form does not accept file uploads. After we reply, we will explain how to
                share drawings or documents.
              </p>

              <div className="mt-12 border-l-[3px] border-ink pl-5">
                <h2 className="font-display text-[1.0625rem] font-medium tracking-tight">Professional responsibility</h2>
                <p className="small text-muted mt-2">{SITE.licensingNotice}</p>
              </div>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}
