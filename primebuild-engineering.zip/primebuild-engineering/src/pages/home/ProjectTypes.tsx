import { Link } from "react-router-dom";
import { PROJECT_TYPES_CONTENT } from "../../data/content";
import { ROUTES } from "../../lib/site";

export function ProjectTypes() {
  return (
    <section id="project-types" aria-labelledby="types-title" className="theme-light section">
      <div className="wrap">
        <div className="grid gap-6 md:grid-cols-12 md:gap-x-6">
          <h2 id="types-title" className="h-section md:col-span-7">
            Projects we support
          </h2>
          <p className="lede text-muted md:col-span-5 md:col-start-8 md:self-end">
            Not sure where yours fits? Choose the closest one, or describe it in your own words.
          </p>
        </div>

        <ul className="mt-14 border-t border-(--rule-strong)">
          {PROJECT_TYPES_CONTENT.map((p) => (
            <li key={p.value} className="rule-b">
              <Link
                to={`${ROUTES.contact}?type=${p.value}`}
                className="group grid gap-2 py-6 transition-colors hover:bg-ink/[0.035] md:grid-cols-12 md:gap-x-6 md:px-3"
              >
                <span className="h-item md:col-span-5">{p.name}</span>
                <span className="text-muted md:col-span-4">{p.description}</span>
                <span className="small md:col-span-3 md:text-right">
                  <span className="text-muted">Often needs: </span>
                  <span className="group-hover:underline group-hover:decoration-1 group-hover:underline-offset-4">{p.often}</span>
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
