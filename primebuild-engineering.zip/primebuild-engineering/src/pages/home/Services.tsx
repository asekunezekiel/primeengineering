import { Link } from "react-router-dom";
import { SERVICES_CONTENT } from "../../data/content";
import { ROUTES } from "../../lib/site";
import { Rule } from "../../components/Rule";

export function Services() {
  return (
    <section id="services" aria-labelledby="services-title" className="theme-dark section">
      <div className="wrap grid gap-12 md:grid-cols-12 md:gap-x-6">
        <div className="md:col-span-4">
          <div className="md:sticky md:top-28">
            <h2 id="services-title" className="h-section">
              Engineering services
            </h2>
            <p className="lede text-muted mt-6">
              Four areas that often work together. Hire one, or ask us to coordinate several.
            </p>
          </div>
        </div>

        <div className="md:col-span-8">
          {SERVICES_CONTENT.map((s, i) => (
            <article key={s.key} aria-labelledby={`svc-${s.key}`} className={i === 0 ? "" : "mt-16 md:mt-20"}>
              <Rule />
              <div className="grid gap-8 pt-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,18rem)] lg:gap-x-12">
                <div>
                  <h3 id={`svc-${s.key}`} className="h-item">
                    {s.name}
                  </h3>
                  <p className="mt-4 max-w-xl text-paper/85">{s.summary}</p>
                  {s.note && <p className="small text-muted mt-4 max-w-xl">{s.note}</p>}
                  <p className="mt-7">
                    <Link to={`${ROUTES.contact}?services=${s.key}`} className="link-line font-semibold">
                      Ask about {s.name.toLowerCase()}
                    </Link>
                  </p>
                </div>
                <div>
                  <h4 className="font-sans text-[0.9375rem] font-semibold tracking-normal">Typical scope</h4>
                  <ul className="mt-3 space-y-2">
                    {s.scope.map((item) => (
                      <li key={item} className="small flex gap-3 text-paper/85">
                        <span aria-hidden="true" className="mt-[0.6em] h-1.5 w-1.5 flex-none bg-lime" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
