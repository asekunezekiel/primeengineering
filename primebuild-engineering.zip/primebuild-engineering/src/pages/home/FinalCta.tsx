import { Button } from "../../components/Button";
import { ROUTES, SITE } from "../../lib/site";

export function FinalCta() {
  return (
    <section aria-labelledby="cta-title" className="theme-dark section">
      <div className="wrap grid gap-10 md:grid-cols-12 md:gap-x-6">
        <h2 id="cta-title" className="h-display md:col-span-9" style={{ fontSize: "clamp(2.6rem, 6.4vw, 5.8rem)" }}>
          Tell us what you’re building.
        </h2>
        <div className="md:col-span-4 md:col-start-1">
          <p className="lede text-paper/85">
            Share the location, project type and timeline. We will review it and reply with next steps.
          </p>
          <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center">
            <Button to={ROUTES.contact}>Start Your Project</Button>
            <a href={`mailto:${SITE.email}`} className="link-line small break-all font-semibold">
              {SITE.email}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
