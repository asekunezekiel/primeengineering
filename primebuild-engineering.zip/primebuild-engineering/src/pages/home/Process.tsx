import { PROCESS } from "../../data/content";

export function Process() {
  return (
    <section id="process" aria-labelledby="process-title" className="theme-light section">
      <div className="wrap">
        <h2 id="process-title" className="h-section max-w-3xl">
          How a project works
        </h2>

        <ol className="mt-14 grid gap-10 lg:grid-cols-5 lg:gap-x-6">
          {PROCESS.map((s, i) => (
            <li key={s.title} className="relative lg:pt-8">
              <div aria-hidden="true" className="absolute left-0 right-0 top-0 hidden h-px bg-(--rule-strong) lg:block" />
              <div className="flex items-center gap-4 lg:block">
                <span
                  aria-hidden="true"
                  className="flex h-9 w-9 flex-none items-center justify-center rounded-full border border-ink bg-paper font-display text-sm font-semibold lg:absolute lg:-top-[18px] lg:left-0"
                >
                  {i + 1}
                </span>
                <h3 className="font-display text-[1.25rem] font-medium leading-snug tracking-tight lg:mt-4">
                  <span className="sr-only">Step {i + 1}: </span>
                  {s.title}
                </h3>
              </div>
              <p className="text-muted mt-3 lg:max-w-[16rem]">{s.body}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
