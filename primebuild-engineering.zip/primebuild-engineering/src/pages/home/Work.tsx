import { WORK_SAMPLES, type WorkSample } from "../../data/workSamples";
import { SampleFraming } from "../../graphics/SampleFraming";
import { SampleDetail } from "../../graphics/SampleDetail";
import { SampleSite } from "../../graphics/SampleSite";

const GRAPHICS = { framing: SampleFraming, detail: SampleDetail, site: SampleSite } as const;

function Item({ item }: { item: WorkSample }) {
  const Graphic = item.kind === "sample" ? GRAPHICS[item.graphic] : null;
  return (
    <figure>
      <div className="relative aspect-[4/3] overflow-hidden border border-ink/25 bg-ink">
        {item.kind === "project" ? (
          <img
            src={item.image.src}
            alt={item.image.alt}
            width={item.image.width}
            height={item.image.height}
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover"
          />
        ) : (
          Graphic && <Graphic />
        )}
      </div>
      <figcaption className="mt-4">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <h3 className="font-display text-[1.1875rem] font-medium tracking-tight">{item.title}</h3>
          <span className="small inline-flex items-center gap-2 border border-ink/40 px-2 py-0.5 font-medium">
            <span aria-hidden="true" className="h-1.5 w-1.5 bg-ink" />
            {item.kind === "sample" ? "Sample graphic" : "Project drawing"}
          </span>
        </div>
        <p className="small text-muted mt-2">{item.caption}</p>
      </figcaption>
    </figure>
  );
}

export function Work() {
  const allSamples = WORK_SAMPLES.every((w) => w.kind === "sample");
  return (
    <section id="work" aria-labelledby="work-title" className="theme-light section">
      <div className="wrap">
        <div className="grid gap-6 md:grid-cols-12 md:gap-x-6">
          <h2 id="work-title" className="h-section md:col-span-7">
            Work samples
          </h2>
          <p className="lede text-muted md:col-span-5 md:col-start-8 md:self-end">
            {allSamples
              ? "Real project drawings appear here once a client has approved sharing them. Until then, these labeled graphics show the kinds of documents we prepare."
              : "Selected drawings and details shared with permission."}
          </p>
        </div>

        <div className="mt-14 grid gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
          {WORK_SAMPLES.map((w) => (
            <Item key={w.id} item={w} />
          ))}
        </div>
      </div>
    </section>
  );
}
