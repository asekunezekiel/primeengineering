import { PRINCIPLES } from "../../data/content";
import { SITE } from "../../lib/site";

export function Why() {
  return (
    <section id="why" aria-labelledby="why-title" className="theme-dark section">
      <div className="wrap">
        <h2 id="why-title" className="h-section max-w-3xl">
          Why PrimeBuild
        </h2>

        <div className="mt-14 grid gap-x-6 md:grid-cols-12">
          <ul className="grid gap-x-10 gap-y-12 sm:grid-cols-2 md:col-span-8">
            {PRINCIPLES.map((p) => (
              <li key={p.title} className="rule-t pt-6">
                <h3 className="h-item">{p.title}</h3>
                <p className="mt-3 text-paper/80">{p.body}</p>
              </li>
            ))}
          </ul>

          <aside
            aria-labelledby="responsibility-title"
            className="mt-14 border-l-[3px] border-lime pl-6 md:col-span-4 md:mt-0"
          >
            <h3 id="responsibility-title" className="font-display text-[1.1875rem] font-medium tracking-tight">
              Professional responsibility
            </h3>
            <p className="small text-paper/80 mt-3">{SITE.licensingNotice}</p>
          </aside>
        </div>
      </div>
    </section>
  );
}
