import { Button } from "../../components/Button";
import { HeroGraphic } from "../../graphics/HeroGraphic";
import { HERO_PHOTO, ROUTES, SITE } from "../../lib/site";

const lines = ["Engineering", "for what’s", "next."];

export function Hero() {
  return (
    <section aria-labelledby="hero-title" className="theme-dark relative overflow-hidden">
      {/* column grid lines */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="wrap grid h-full grid-cols-4 md:grid-cols-12">
          {Array.from({ length: 12 }).map((_, i) => (
            <div
              key={i}
              className={`border-l border-paper/[0.06] ${i >= 4 ? "hidden md:block" : ""} ${i === 11 ? "border-r" : ""}`}
            />
          ))}
        </div>
      </div>

      <div className="wrap relative grid gap-12 pb-16 pt-[7.5rem] md:grid-cols-12 md:gap-x-6 md:pb-24 md:pt-[9.5rem] lg:pt-[11rem]">
        <div className="md:col-span-7">
          <p className="eyebrow hero-fade text-lime" style={{ animationDelay: "0.05s" }}>
            Multidisciplinary Engineering Services
          </p>

          <h1 id="hero-title" className="h-display mt-7">
            <span className="sr-only">Engineering for what’s next.</span>
            {lines.map((line, i) => (
              <span key={line} aria-hidden="true" className="line-mask">
                <span className="line-in" style={{ animationDelay: `${0.15 + i * 0.12}s` }}>
                  {line}
                </span>
              </span>
            ))}
          </h1>

          <p className="lede hero-fade mt-9 text-paper/85" style={{ animationDelay: "0.65s" }}>
            Structural, civil, building, and MEP engineering support for projects that need clear scope, coordinated
            documentation, and practical technical solutions.
          </p>

          <div className="hero-fade mt-10 flex flex-col gap-3 sm:flex-row" style={{ animationDelay: "0.8s" }}>
            <Button to={ROUTES.contact}>Start Your Project</Button>
            <Button to={{ pathname: ROUTES.home, hash: "services" }} variant="secondary">
              Explore Services
            </Button>
          </div>
        </div>

        <figure className="hero-fade md:col-span-5 md:col-start-8" style={{ animationDelay: "0.5s" }}>
          <div className="relative overflow-hidden border border-(--rule)">
            {HERO_PHOTO ? (
              <img
                src={HERO_PHOTO.src}
                alt={HERO_PHOTO.alt}
                width={HERO_PHOTO.width}
                height={HERO_PHOTO.height}
                fetchPriority="high"
                className="h-auto w-full"
              />
            ) : (
              <HeroGraphic className="h-auto w-full" />
            )}
          </div>
          {!HERO_PHOTO && (
            <figcaption className="small text-muted mt-3">Illustration of a structural grid. Not a client project.</figcaption>
          )}
        </figure>
      </div>

      <div className="wrap relative">
        <div className="rule-t py-7">
          <p className="font-display text-[1.0625rem] font-medium tracking-tight text-paper/90 sm:text-lg">{SITE.brandStatement}</p>
        </div>
      </div>
    </section>
  );
}
