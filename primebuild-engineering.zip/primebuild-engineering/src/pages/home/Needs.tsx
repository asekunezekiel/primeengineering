import { useRef, useState, type KeyboardEvent } from "react";
import { Link } from "react-router-dom";
import { AUDIENCES, SERVICES_CONTENT } from "../../data/content";
import { ROUTES } from "../../lib/site";
import { Rule } from "../../components/Rule";

const SERVICE_NAME = Object.fromEntries(SERVICES_CONTENT.map((s) => [s.key, s.name]));

export function Needs() {
  const [active, setActive] = useState(0);
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);

  const onKey = (e: KeyboardEvent<HTMLButtonElement>, i: number) => {
    let next = i;
    if (e.key === "ArrowDown" || e.key === "ArrowRight") next = (i + 1) % AUDIENCES.length;
    else if (e.key === "ArrowUp" || e.key === "ArrowLeft") next = (i - 1 + AUDIENCES.length) % AUDIENCES.length;
    else if (e.key === "Home") next = 0;
    else if (e.key === "End") next = AUDIENCES.length - 1;
    else return;
    e.preventDefault();
    setActive(next);
    tabs.current[next]?.focus();
  };

  const current = AUDIENCES[active]!;

  return (
    <section id="start" aria-labelledby="needs-title" className="theme-light section">
      <div className="wrap">
        <div className="grid gap-10 md:grid-cols-12 md:gap-x-6">
          <div className="md:col-span-5">
            <h2 id="needs-title" className="h-section">
              Find your starting point.
            </h2>
            <p className="lede text-muted mt-6">
              Pick the description closest to you. We will show what usually matters first, then you can tell us the details.
            </p>
          </div>

          <div className="md:col-span-7">
            <div className="grid gap-8 lg:grid-cols-[minmax(0,17rem)_minmax(0,1fr)] lg:gap-x-10">
              <div role="tablist" aria-label="Who you are" aria-orientation="vertical" className="flex flex-col">
                {AUDIENCES.map((a, i) => {
                  const selected = i === active;
                  return (
                    <button
                      key={a.id}
                      ref={(el) => {
                        tabs.current[i] = el;
                      }}
                      role="tab"
                      type="button"
                      id={`tab-${a.id}`}
                      aria-selected={selected}
                      aria-controls={`panel-${a.id}`}
                      tabIndex={selected ? 0 : -1}
                      onClick={() => setActive(i)}
                      onKeyDown={(e) => onKey(e, i)}
                      className={`rule-t relative py-4 pl-5 pr-2 text-left font-display text-[1.0625rem] font-medium leading-snug tracking-tight transition-colors last:border-b last:border-(--rule) ${
                        selected ? "text-ink" : "text-muted hover:text-ink"
                      }`}
                    >
                      <span
                        aria-hidden="true"
                        className={`absolute left-0 top-1/2 h-2.5 w-2.5 -translate-y-1/2 transition-all ${
                          selected ? "bg-lime ring-1 ring-ink" : "bg-transparent"
                        }`}
                      />
                      {a.label}
                    </button>
                  );
                })}
              </div>

              <div
                role="tabpanel"
                id={`panel-${current.id}`}
                aria-labelledby={`tab-${current.id}`}
                tabIndex={0}
                className="rounded-sm"
              >
                <p className="font-display text-[1.375rem] font-medium leading-snug tracking-tight">{current.intro}</p>
                <h3 className="font-sans mt-8 text-[0.9375rem] font-semibold tracking-normal">What this often looks like</h3>
                <ul className="mt-3 space-y-3">
                  {current.needs.map((n) => (
                    <li key={n} className="rule-t flex gap-3 pt-3">
                      <span aria-hidden="true" className="mt-[0.7em] h-1.5 w-1.5 flex-none bg-ink" />
                      <span>{n}</span>
                    </li>
                  ))}
                </ul>
                <p className="small text-muted mt-8">
                  Usually starts with: {current.starts.map((s) => SERVICE_NAME[s]).join(" and ")}.
                </p>
                <div className="mt-6">
                  <Link
                    to={`${ROUTES.contact}?services=${current.starts.join(",")}`}
                    className="btn btn-primary"
                  >
                    Start with this
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Rule className="mt-20" />
      </div>
    </section>
  );
}
