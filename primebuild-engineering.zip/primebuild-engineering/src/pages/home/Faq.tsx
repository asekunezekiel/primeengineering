import { useState } from "react";
import { FAQS } from "../../data/content";
import { SITE } from "../../lib/site";

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" aria-labelledby="faq-title" className="theme-light section pt-0">
      <div className="wrap">
        <div className="rule-t" />
        <div className="grid gap-10 pt-16 md:grid-cols-12 md:gap-x-6 md:pt-24">
          <div className="md:col-span-4">
            <h2 id="faq-title" className="h-section">
              Frequently asked questions
            </h2>
            <p className="text-muted mt-6">
              Something missing? Email{" "}
              <a href={`mailto:${SITE.email}`} className="link-line break-all font-semibold text-ink">
                {SITE.email}
              </a>
              .
            </p>
          </div>

          <div className="md:col-span-8">
            <ul className="border-t border-(--rule-strong)">
              {FAQS.map((f, i) => {
                const isOpen = open === i;
                return (
                  <li key={f.q} className="rule-b">
                    <h3>
                      <button
                        type="button"
                        id={`faq-btn-${i}`}
                        aria-expanded={isOpen}
                        aria-controls={`faq-panel-${i}`}
                        onClick={() => setOpen(isOpen ? null : i)}
                        className="flex w-full items-start justify-between gap-6 py-5 text-left font-display text-[1.1875rem] font-medium leading-snug tracking-tight"
                      >
                        <span>{f.q}</span>
                        <span aria-hidden="true" className="relative mt-2 h-3 w-3 flex-none">
                          <span className="absolute left-0 top-1/2 h-[2px] w-3 -translate-y-1/2 bg-ink" />
                          <span
                            className={`absolute left-1/2 top-0 h-3 w-[2px] -translate-x-1/2 bg-ink transition-transform duration-200 ${
                              isOpen ? "scale-y-0" : ""
                            }`}
                          />
                        </span>
                      </button>
                    </h3>
                    <div
                      id={`faq-panel-${i}`}
                      role="region"
                      aria-labelledby={`faq-btn-${i}`}
                      data-open={isOpen}
                      className="accordion-panel"
                    >
                      <div>
                        <p className="text-muted max-w-2xl pb-6">{f.a}</p>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
