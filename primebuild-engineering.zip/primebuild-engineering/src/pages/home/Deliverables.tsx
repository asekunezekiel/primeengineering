import { DELIVERABLES } from "../../data/content";
import { SITE } from "../../lib/site";

export function Deliverables() {
  return (
    <section id="deliverables" aria-labelledby="deliverables-title" className="theme-dark section">
      <div className="wrap">
        <div className="grid gap-6 md:grid-cols-12 md:gap-x-6">
          <h2 id="deliverables-title" className="h-section md:col-span-7">
            What you receive
          </h2>
          <p className="lede text-muted md:col-span-5 md:col-start-8 md:self-end">
            The documents behind a permit, in plain terms. Final deliverables depend on your scope and jurisdiction.
          </p>
        </div>

        <ul className="mt-14 border-t border-(--rule-strong)">
          {DELIVERABLES.map((d) => (
            <li key={d.name} className="rule-b grid gap-1.5 py-5 md:grid-cols-12 md:items-baseline md:gap-x-6">
              <h3 className="font-display text-[1.1875rem] font-medium leading-snug tracking-tight md:col-span-4">{d.name}</h3>
              <p className="text-paper/80 md:col-span-6">{d.what}</p>
              <p className="small text-muted md:col-span-2 md:text-right">{d.service}</p>
            </li>
          ))}
        </ul>

        <p className="small text-muted mt-8 max-w-3xl">{SITE.licensingNotice}</p>
      </div>
    </section>
  );
}
