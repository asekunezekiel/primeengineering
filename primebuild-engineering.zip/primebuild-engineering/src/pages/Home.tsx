import { useDocumentMeta } from "../hooks/useDocumentMeta";
import { Hero } from "./home/Hero";
import { Needs } from "./home/Needs";
import { Services } from "./home/Services";
import { ProjectTypes } from "./home/ProjectTypes";
import { Deliverables } from "./home/Deliverables";
import { Work } from "./home/Work";
import { Why } from "./home/Why";
import { Process } from "./home/Process";
import { Faq } from "./home/Faq";
import { FinalCta } from "./home/FinalCta";

export const HOME_META = {
  title: "PrimeBuild Engineering | Structural, Civil, Permit & MEP Services",
  description:
    "Explore structural engineering, civil and site plans, building permit documentation, MEP services, and energy compliance support for eligible U.S. projects.",
  path: "/",
};

export function Home() {
  useDocumentMeta(HOME_META);
  return (
    <>
      <Hero />
      <Needs />
      <Services />
      <ProjectTypes />
      <Deliverables />
      <Work />
      <Why />
      <Process />
      <Faq />
      <FinalCta />
    </>
  );
}
