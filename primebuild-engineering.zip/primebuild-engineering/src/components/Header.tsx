import { useEffect, useRef, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { NAV, ROUTES } from "../lib/site";
import { Wordmark } from "./Wordmark";
import { Button } from "./Button";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const panelRef = useRef<HTMLDivElement>(null);
  const toggleRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [location.pathname, location.hash, location.key]);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        toggleRef.current?.focus();
        return;
      }
      if (e.key !== "Tab") return;
      const focusable = [
        toggleRef.current,
        ...(panelRef.current?.querySelectorAll<HTMLElement>("a[href], button:not([disabled])") ?? []),
      ].filter(Boolean) as HTMLElement[];
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (!first || !last) return;
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const solid = scrolled || open;

  return (
    <header
      className={`theme-dark fixed inset-x-0 top-0 z-50 transition-colors duration-300 ${
        solid ? "border-b border-(--rule) bg-ink/92 backdrop-blur-md" : "border-b border-transparent bg-transparent"
      }`}
      style={solid ? undefined : { background: "transparent" }}
    >
      <div className="wrap flex h-[72px] items-center justify-between gap-6">
        <Link to={ROUTES.home} aria-label="PrimeBuild Engineering, home" className="rounded-sm">
          <Wordmark className="w-[7.1rem]" />
        </Link>

        <nav aria-label="Primary" className="hidden items-center gap-7 lg:flex">
          {NAV.map((item) => (
            <Link
              key={item.hash}
              to={{ pathname: ROUTES.home, hash: item.hash }}
              className="link-line text-[0.9375rem] font-medium text-paper/80 hover:text-paper"
              style={{ backgroundSize: "0% 1px" }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundSize = "100% 1px")}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundSize = "0% 1px")}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <Button to={ROUTES.contact} className="hidden !min-h-11 !px-5 !py-2.5 !text-[0.9375rem] sm:inline-flex">
            Start Your Project
          </Button>
          <button
            ref={toggleRef}
            type="button"
            className="flex h-11 w-11 items-center justify-center rounded-sm border border-(--rule) lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            <span aria-hidden="true" className="relative block h-3 w-5">
              <span
                className={`absolute left-0 h-[2px] w-5 bg-current transition-all duration-200 ${
                  open ? "top-[5px] rotate-45" : "top-0"
                }`}
              />
              <span
                className={`absolute left-0 h-[2px] w-5 bg-current transition-all duration-200 ${
                  open ? "top-[5px] -rotate-45" : "top-[10px]"
                }`}
              />
            </span>
          </button>
        </div>
      </div>

      <div
        id="mobile-menu"
        ref={panelRef}
        hidden={!open}
        className="theme-dark fixed inset-x-0 top-[72px] h-[calc(100dvh-72px)] overflow-y-auto border-t border-(--rule) lg:hidden"
      >
        <nav aria-label="Mobile" className="wrap flex min-h-full flex-col py-8">
          <ul>
            {NAV.map((item) => (
              <li key={item.hash} className="rule-b">
                <Link
                  to={{ pathname: ROUTES.home, hash: item.hash }}
                  className="flex min-h-16 items-center font-display text-[1.65rem] font-medium tracking-tight"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-10">
            <Button to={ROUTES.contact} className="w-full">
              Start Your Project
            </Button>
          </div>
        </nav>
      </div>
    </header>
  );
}
