import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { useSearchParams } from "react-router-dom";
import {
  PROJECT_TYPES,
  SERVICES,
  TIMELINES,
  US_STATES,
  flattenErrors,
  inquirySchema,
  type FieldErrors,
} from "../lib/inquirySchema";
import { SITE } from "../lib/site";
import { Turnstile } from "./Turnstile";

type Values = {
  name: string;
  email: string;
  company: string;
  city: string;
  state: string;
  projectType: string;
  services: string[];
  description: string;
  timeline: string;
  consent: boolean;
  website: string;
};

const EMPTY: Values = {
  name: "",
  email: "",
  company: "",
  city: "",
  state: "",
  projectType: "",
  services: [],
  description: "",
  timeline: "",
  consent: false,
  website: "",
};

type Status = "idle" | "submitting" | "success" | "error";

const FIELD_LABELS: Record<string, string> = {
  name: "Name",
  email: "Email",
  city: "City or county",
  state: "State",
  projectType: "Project type",
  services: "Services needed",
  description: "Project description",
  timeline: "Target timeline",
  consent: "Consent",
};

function Field({
  id,
  label,
  optional,
  hint,
  error,
  children,
}: {
  id: string;
  label: string;
  optional?: boolean;
  hint?: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <div>
      <label htmlFor={id} className="field-label">
        {label}
        {optional && <span className="text-muted font-normal"> (optional)</span>}
      </label>
      {hint && (
        <p id={`${id}-hint`} className="field-hint">
          {hint}
        </p>
      )}
      {children}
      {error && (
        <p id={`${id}-error`} className="field-error">
          {error}
        </p>
      )}
    </div>
  );
}

export function InquiryForm() {
  const [params] = useSearchParams();
  const initial = useMemo<Values>(() => {
    const validServices = new Set<string>(SERVICES.map((s) => s.value));
    const validTypes = new Set<string>(PROJECT_TYPES.map((p) => p.value));
    const services = (params.get("services") ?? "").split(",").filter((s) => validServices.has(s));
    const type = params.get("type") ?? "";
    return { ...EMPTY, services, projectType: validTypes.has(type) ? type : "" };
  }, [params]);

  const [values, setValues] = useState<Values>(initial);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [status, setStatus] = useState<Status>("idle");
  const [serverMessage, setServerMessage] = useState("");
  const [token, setToken] = useState("");
  const [resetSignal, setResetSignal] = useState(0);
  const startedAt = useRef(Date.now());
  const summaryRef = useRef<HTMLDivElement>(null);
  const successRef = useRef<HTMLHeadingElement>(null);
  const turnstileOn = Boolean(SITE.turnstileSiteKey);

  useEffect(() => {
    setValues((v) => ({ ...v, services: initial.services, projectType: initial.projectType || v.projectType }));
  }, [initial]);

  const set = <K extends keyof Values>(key: K, value: Values[K]) => {
    setValues((v) => ({ ...v, [key]: value }));
    if (errors[key as keyof FieldErrors]) setErrors((e) => ({ ...e, [key]: undefined }));
  };

  const toggleService = (value: string) => {
    const has = values.services.includes(value);
    let next: string[];
    if (value === "not-sure") next = has ? [] : ["not-sure"];
    else next = has ? values.services.filter((s) => s !== value) : [...values.services.filter((s) => s !== "not-sure"), value];
    set("services", next);
  };

  const describe = (id: string, hint: boolean, hasError: boolean) =>
    [hint ? `${id}-hint` : "", hasError ? `${id}-error` : ""].filter(Boolean).join(" ") || undefined;

  const showSummary = (e: FieldErrors) => {
    setErrors(e);
    setStatus("idle");
    requestAnimationFrame(() => summaryRef.current?.focus());
  };

  const onSubmit = async (ev: FormEvent) => {
    ev.preventDefault();
    if (status === "submitting") return;
    setServerMessage("");

    const payload = {
      ...values,
      startedAt: startedAt.current,
      turnstileToken: token,
    };
    const parsed = inquirySchema.safeParse(payload);
    const clientErrors: FieldErrors = parsed.success ? {} : flattenErrors(parsed.error);
    if (turnstileOn && !token) {
      clientErrors.turnstileToken = "Complete the spam check below.";
    }
    if (Object.keys(clientErrors).length > 0) {
      showSummary(clientErrors);
      return;
    }

    setErrors({});
    setStatus("submitting");
    try {
      const res = await fetch("/api/inquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      let body: { ok?: boolean; message?: string; errors?: FieldErrors } = {};
      try {
        body = await res.json();
      } catch {
        /* non-JSON error page */
      }
      if (res.ok && body.ok === true) {
        setStatus("success");
        requestAnimationFrame(() => successRef.current?.focus());
        return;
      }
      if (res.status === 400 && body.errors) {
        showSummary(body.errors);
        return;
      }
      setServerMessage(
        res.status === 503
          ? "Online submissions are not available right now."
          : body.message || "We could not send your inquiry.",
      );
      setStatus("error");
      setResetSignal((n) => n + 1);
      requestAnimationFrame(() => summaryRef.current?.focus());
    } catch {
      setServerMessage("We could not reach the server. Check your connection and try again.");
      setStatus("error");
      setResetSignal((n) => n + 1);
      requestAnimationFrame(() => summaryRef.current?.focus());
    }
  };

  const reset = () => {
    setValues(EMPTY);
    setErrors({});
    setStatus("idle");
    setToken("");
    setResetSignal((n) => n + 1);
    startedAt.current = Date.now();
  };

  if (status === "success") {
    return (
      <div role="status" className="border border-ink bg-white p-8 md:p-10">
        <h2 ref={successRef} tabIndex={-1} className="h-item outline-none">
          Your inquiry was sent.
        </h2>
        <p className="mt-4 max-w-xl">
          Thank you, {values.name.split(" ")[0]}. We will review the details and reply to {values.email} with next steps. If
          we need more information or files, we will tell you how to share them.
        </p>
        <p className="small text-muted mt-4">
          Nothing in this inquiry is a commitment to provide services, stamps or sealed documents. We will confirm scope,
          jurisdiction and licensing with you first.
        </p>
        <button type="button" onClick={reset} className="btn btn-secondary mt-8">
          Send another inquiry
        </button>
      </div>
    );
  }

  const errorEntries = Object.entries(errors).filter(([, v]) => v) as [string, string][];

  return (
    <form onSubmit={onSubmit} noValidate aria-label="Project inquiry" className="space-y-8">
      <div
        ref={summaryRef}
        tabIndex={-1}
        role={errorEntries.length > 0 || status === "error" ? "alert" : undefined}
        className="outline-none"
      >
        {errorEntries.length > 0 && (
          <div className="border-l-[3px] border-[#b3261e] bg-[#fdf0ee] p-5">
            <h2 className="font-display text-lg font-semibold tracking-tight text-[#7a1510]">
              Please fix {errorEntries.length === 1 ? "1 field" : `${errorEntries.length} fields`} before sending.
            </h2>
            <ul className="mt-2 space-y-1 text-[#7a1510]">
              {errorEntries.map(([k, msg]) => (
                <li key={k}>
                  <a href={`#f-${k}`} className="underline underline-offset-2">
                    {FIELD_LABELS[k] ?? "Spam check"}: {msg}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}
        {status === "error" && (
          <div className="border-l-[3px] border-[#b3261e] bg-[#fdf0ee] p-5 text-[#7a1510]">
            <h2 className="font-display text-lg font-semibold tracking-tight">Your inquiry was not sent.</h2>
            <p className="mt-2">{serverMessage}</p>
            <p className="mt-2">
              You can try again, or email us directly at{" "}
              <a className="font-semibold underline underline-offset-2" href={`mailto:${SITE.email}`}>
                {SITE.email}
              </a>
              .
            </p>
          </div>
        )}
      </div>

      <p className="small text-muted">Every field is required unless it is marked optional.</p>

      <div className="grid gap-6 sm:grid-cols-2">
        <Field id="f-name" label="Name" error={errors.name}>
          <input
            id="f-name"
            name="name"
            autoComplete="name"
            className="control"
            value={values.name}
            onChange={(e) => set("name", e.target.value)}
            aria-invalid={Boolean(errors.name)}
            aria-describedby={describe("f-name", false, Boolean(errors.name))}
            aria-required="true"
          />
        </Field>
        <Field id="f-email" label="Email" error={errors.email}>
          <input
            id="f-email"
            name="email"
            type="email"
            autoComplete="email"
            inputMode="email"
            className="control"
            value={values.email}
            onChange={(e) => set("email", e.target.value)}
            aria-invalid={Boolean(errors.email)}
            aria-describedby={describe("f-email", false, Boolean(errors.email))}
            aria-required="true"
          />
        </Field>
      </div>

      <Field id="f-company" label="Company" optional error={errors.company}>
        <input
          id="f-company"
          name="company"
          autoComplete="organization"
          className="control"
          value={values.company}
          onChange={(e) => set("company", e.target.value)}
        />
      </Field>

      <div className="grid gap-6 sm:grid-cols-[minmax(0,1fr)_minmax(0,14rem)]">
        <Field id="f-city" label="Project city or county" error={errors.city}>
          <input
            id="f-city"
            name="city"
            autoComplete="address-level2"
            className="control"
            value={values.city}
            onChange={(e) => set("city", e.target.value)}
            aria-invalid={Boolean(errors.city)}
            aria-describedby={describe("f-city", false, Boolean(errors.city))}
            aria-required="true"
          />
        </Field>
        <Field id="f-state" label="State" error={errors.state}>
          <select
            id="f-state"
            name="state"
            className="control"
            value={values.state}
            onChange={(e) => set("state", e.target.value)}
            aria-invalid={Boolean(errors.state)}
            aria-describedby={describe("f-state", false, Boolean(errors.state))}
            aria-required="true"
          >
            <option value="">Choose a state</option>
            {US_STATES.map(([code, name]) => (
              <option key={code} value={code}>
                {name}
              </option>
            ))}
          </select>
        </Field>
      </div>

      <Field id="f-projectType" label="Project type" error={errors.projectType}>
        <select
          id="f-projectType"
          name="projectType"
          className="control"
          value={values.projectType}
          onChange={(e) => set("projectType", e.target.value)}
          aria-invalid={Boolean(errors.projectType)}
          aria-describedby={describe("f-projectType", false, Boolean(errors.projectType))}
          aria-required="true"
        >
          <option value="">Choose the closest match</option>
          {PROJECT_TYPES.map((p) => (
            <option key={p.value} value={p.value}>
              {p.label}
            </option>
          ))}
        </select>
      </Field>

      <fieldset
        id="f-services"
        tabIndex={-1}
        aria-describedby={describe("f-services", true, Boolean(errors.services))}
        className="min-w-0 outline-none"
      >
        <legend className="field-label">Services needed</legend>
        <p id="f-services-hint" className="field-hint">
          Choose all that apply.
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          {SERVICES.map((s) => (
            <label key={s.value} className="check">
              <input
                type="checkbox"
                name="services"
                value={s.value}
                checked={values.services.includes(s.value)}
                onChange={() => toggleService(s.value)}
              />
              <span>{s.label}</span>
            </label>
          ))}
        </div>
        {errors.services && (
          <p id="f-services-error" className="field-error">
            {errors.services}
          </p>
        )}
      </fieldset>

      <Field
        id="f-description"
        label="Project description"
        hint="What do you want to build or change? Include size, current stage, and any permit comments you have."
        error={errors.description}
      >
        <textarea
          id="f-description"
          name="description"
          rows={6}
          className="control resize-y"
          value={values.description}
          onChange={(e) => set("description", e.target.value)}
          aria-invalid={Boolean(errors.description)}
          aria-describedby={describe("f-description", true, Boolean(errors.description))}
          aria-required="true"
          maxLength={4000}
        />
        <p className="small text-muted mt-1 text-right" aria-hidden="true">
          {values.description.length} / 4000
        </p>
      </Field>

      <Field id="f-timeline" label="Target timeline" error={errors.timeline}>
        <select
          id="f-timeline"
          name="timeline"
          className="control"
          value={values.timeline}
          onChange={(e) => set("timeline", e.target.value)}
          aria-invalid={Boolean(errors.timeline)}
          aria-describedby={describe("f-timeline", false, Boolean(errors.timeline))}
          aria-required="true"
        >
          <option value="">Choose a timeline</option>
          {TIMELINES.map((t) => (
            <option key={t.value} value={t.value}>
              {t.label}
            </option>
          ))}
        </select>
      </Field>

      {/* Honeypot: hidden from people and assistive tech. Bots tend to fill it. */}
      <div className="sr-only-hp" aria-hidden="true">
        <label>
          Leave this field empty
          <input
            type="text"
            name="website"
            tabIndex={-1}
            autoComplete="off"
            value={values.website}
            onChange={(e) => set("website", e.target.value)}
          />
        </label>
      </div>

      <div>
        <label id="f-consent" tabIndex={-1} className="check outline-none">
          <input
            type="checkbox"
            name="consent"
            checked={values.consent}
            onChange={(e) => set("consent", e.target.checked)}
            aria-invalid={Boolean(errors.consent)}
            aria-describedby={errors.consent ? "f-consent-error" : undefined}
          />
          <span className="small">
            I agree that PrimeBuild Engineering may use these details to review my project and reply to me.
          </span>
        </label>
        {errors.consent && (
          <p id="f-consent-error" className="field-error">
            {errors.consent}
          </p>
        )}
      </div>

      {turnstileOn && (
        <div id="f-turnstileToken">
          <Turnstile siteKey={SITE.turnstileSiteKey} onToken={setToken} resetSignal={resetSignal} />
          {errors.turnstileToken && <p className="field-error">{errors.turnstileToken}</p>}
        </div>
      )}

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <button type="submit" className="btn btn-primary" disabled={status === "submitting"}>
          {status === "submitting" ? "Sending…" : "Send inquiry"}
        </button>
        <p className="small text-muted" aria-live="polite">
          {status === "submitting" ? "Sending your inquiry. This can take a few seconds." : ""}
        </p>
      </div>
    </form>
  );
}
