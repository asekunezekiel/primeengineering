import { useEffect } from "react";
import { useLocation } from "react-router-dom";

/** Scrolls to #hash targets or back to top when the route changes. */
export function ScrollManager() {
  const { pathname, hash, key } = useLocation();
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (hash) {
      const id = decodeURIComponent(hash.slice(1));
      // wait a frame so the target route has rendered
      const raf = requestAnimationFrame(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
      });
      return () => cancelAnimationFrame(raf);
    }
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  }, [pathname, hash, key]);
  return null;
}
