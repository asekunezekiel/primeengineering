export function Wordmark({ className = "" }: { className?: string }) {
  const letters = "ENGINEERING".split("");
  return (
    <span className={`inline-block leading-none ${className}`}>
      <span className="sr-only">PrimeBuild Engineering</span>
      <span aria-hidden="true" className="block font-display text-[1.45rem] font-semibold tracking-[-0.045em]">
        PrimeBuild
      </span>
      <span
        aria-hidden="true"
        className="mt-[5px] flex justify-between font-sans text-[0.5rem] font-semibold"
        style={{ width: "100%" }}
      >
        {letters.map((l, i) => (
          <span key={i}>{l}</span>
        ))}
      </span>
    </span>
  );
}
