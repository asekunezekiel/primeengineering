import { useInView } from "../hooks/useInView";

/** A hairline that draws itself in once when it scrolls into view. */
export function Rule({ className = "" }: { className?: string }) {
  const [ref, inView] = useInView<HTMLDivElement>(0.5);
  return <div ref={ref} aria-hidden="true" className={`rule-draw ${inView ? "is-in" : ""} ${className}`} />;
}
