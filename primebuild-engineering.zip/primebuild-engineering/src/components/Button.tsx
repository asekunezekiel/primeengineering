import { Link, type To } from "react-router-dom";
import type { ReactNode } from "react";

type Props = {
  to?: To;
  href?: string;
  variant?: "primary" | "secondary";
  children: ReactNode;
  className?: string;
  onClick?: () => void;
};

export function Button({ to, href, variant = "primary", children, className = "", onClick }: Props) {
  const cls = `btn btn-${variant} ${className}`;
  if (to) {
    return (
      <Link to={to} className={cls} onClick={onClick}>
        {children}
      </Link>
    );
  }
  return (
    <a href={href} className={cls} onClick={onClick}>
      {children}
    </a>
  );
}
