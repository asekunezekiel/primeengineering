import { Link } from "react-router-dom";
import { NAV, ROUTES, SITE } from "../lib/site";
import { Wordmark } from "./Wordmark";

export function Footer() {
  return (
    <footer className="theme-dark border-t border-(--rule)">
      <div className="wrap grid gap-12 py-14 md:grid-cols-12 md:py-20">
        <div className="md:col-span-5">
          <Wordmark className="w-[8.5rem]" />
          <p className="small text-muted mt-6 max-w-sm">{SITE.brandStatement}</p>
        </div>

        <nav aria-label="Footer" className="md:col-span-3">
          <h2 className="font-sans text-[0.9375rem] font-semibold tracking-normal">Explore</h2>
          <ul className="mt-4 space-y-2.5">
            {NAV.map((item) => (
              <li key={item.hash}>
                <Link to={{ pathname: ROUTES.home, hash: item.hash }} className="link-line text-muted hover:text-paper small">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="md:col-span-4">
          <h2 className="font-sans text-[0.9375rem] font-semibold tracking-normal">Contact</h2>
          <ul className="mt-4 space-y-2.5">
            <li>
              <a href={`mailto:${SITE.email}`} className="link-line small break-all">
                {SITE.email}
              </a>
            </li>
            <li>
              <Link to={ROUTES.contact} className="link-line text-muted hover:text-paper small">
                Send a project inquiry
              </Link>
            </li>
          </ul>
        </div>
      </div>

      <div className="wrap border-t border-(--rule) py-8">
        <p className="small text-muted max-w-4xl">{SITE.licensingNotice}</p>
        <p className="small text-muted mt-4">© {new Date().getFullYear()} PrimeBuild Engineering. All rights reserved.</p>
      </div>
    </footer>
  );
}
