import { useEffect } from "react";

type Meta = { title: string; description: string; path: string };

function setMeta(selector: string, attr: string, value: string) {
  const el = document.head.querySelector<HTMLMetaElement>(selector);
  if (el) el.setAttribute(attr, value);
}

/** Keeps title and social metadata in sync on client-side navigation. */
export function useDocumentMeta({ title, description, path }: Meta) {
  useEffect(() => {
    document.title = title;
    setMeta('meta[name="description"]', "content", description);
    setMeta('meta[property="og:title"]', "content", title);
    setMeta('meta[property="og:description"]', "content", description);
    setMeta('meta[name="twitter:title"]', "content", title);
    setMeta('meta[name="twitter:description"]', "content", description);
    const canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    const ogUrl = document.head.querySelector<HTMLMetaElement>('meta[property="og:url"]');
    const current = canonical?.getAttribute("href") ?? "";
    try {
      const origin = new URL(current).origin;
      const url = origin + path;
      canonical?.setAttribute("href", url);
      ogUrl?.setAttribute("content", url);
    } catch {
      /* canonical not absolute in dev; ignore */
    }
  }, [title, description, path]);
}
