const P = "#FAF9F6";
const L = "#D7FF4F";

/** Schematic site plan with contours and drainage flow. Illustration only. */
export function SampleSite() {
  return (
    <svg viewBox="0 0 480 360" role="img" aria-labelledby="ss-t" className="h-full w-full" xmlns="http://www.w3.org/2000/svg">
      <title id="ss-t">Schematic site plan with a property line, a building, contour lines and arrows showing drainage direction. Sample graphic.</title>
      <rect width="480" height="360" fill="#0F191D" />
      {/* contours */}
      {[0, 1, 2, 3, 4].map((i) => (
        <path
          key={i}
          d={`M20 ${70 + i * 52} C 120 ${40 + i * 52}, 240 ${110 + i * 52}, 460 ${60 + i * 52}`}
          fill="none"
          stroke={P}
          strokeOpacity="0.2"
        />
      ))}
      {/* property line */}
      <polygon points="70,52 410,40 430,300 56,312" fill="none" stroke={P} strokeOpacity="0.75" strokeWidth="1.5" strokeDasharray="10 5 2 5" />
      {/* building */}
      <rect x="170" y="96" width="140" height="84" fill="#172329" stroke={P} strokeWidth="2" />
      {/* swale */}
      <path d="M96 238 C 170 218, 300 262, 400 236" fill="none" stroke={L} strokeWidth="3" />
      {[
        [150, 228, 20],
        [250, 240, 20],
        [350, 248, -10],
      ].map(([x, y, r], i) => (
        <path key={i} d={`M${x - 13} ${y - 8} L${x} ${y} L${x - 13} ${y + 8}`} stroke={L} strokeWidth="3" fill="none" strokeLinejoin="round" strokeLinecap="round" transform={`rotate(${r} ${x} ${y})`} />
      ))}
      <text x="176" y="146" fontSize="12" fill={P} fillOpacity="0.85">Building</text>
      <text x="100" y="272" fontSize="12" fontWeight="600" fill={L}>Drainage swale</text>
      <text x="76" y="76" fontSize="11" fill={P} fillOpacity="0.7">Property line</text>
    </svg>
  );
}
