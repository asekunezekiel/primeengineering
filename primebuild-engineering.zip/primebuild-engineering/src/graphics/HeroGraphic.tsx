/**
 * Abstract building elevation drawn with SVG. This is an illustration, not a client project.
 * It reads as a structural grid: column axes (A to D), level lines, slabs, glazing, and one
 * highlighted diagonal brace. Swap for a licensed photograph through HERO_PHOTO in lib/site.ts.
 */
const PAPER = "#FAF9F6";
const LIME = "#D7FF4F";

export function HeroGraphic({ className = "" }: { className?: string }) {
  const axes = [
    { x: 90, id: "A" },
    { x: 210, id: "B" },
    { x: 330, id: "C" },
    { x: 450, id: "D" },
  ];
  const mullions = (from: number, to: number, y1: number, y2: number) => {
    const out: number[] = [];
    for (let x = from + 30; x < to; x += 30) out.push(x);
    return out.map((x) => <line key={`${x}-${y1}`} x1={x} x2={x} y1={y1} y2={y2} stroke={PAPER} strokeOpacity="0.28" />);
  };

  return (
    <svg
      viewBox="0 0 560 720"
      role="img"
      aria-labelledby="hero-graphic-title hero-graphic-desc"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      <title id="hero-graphic-title">Illustration of a building elevation on a structural grid</title>
      <desc id="hero-graphic-desc">
        An abstract multi-story building with labeled column axes A to D, floor slabs, glazed bays, a solid upper volume, and one
        highlighted diagonal brace. Illustration only.
      </desc>

      <rect width="560" height="720" fill="#0F191D" />

      {/* column axes */}
      {axes.map((a) => (
        <g key={a.id}>
          <line x1={a.x} x2={a.x} y1="64" y2="650" stroke={PAPER} strokeOpacity="0.2" strokeDasharray="3 7" />
          <circle cx={a.x} cy="46" r="14" fill="none" stroke={PAPER} strokeOpacity="0.6" />
          <text x={a.x} y="51" textAnchor="middle" fontSize="13" fontWeight="600" fill={PAPER} fillOpacity="0.9">
            {a.id}
          </text>
        </g>
      ))}

      {/* level lines */}
      {[
        { y: 200, id: "L3" },
        { y: 360, id: "L2" },
        { y: 520, id: "L1" },
      ].map((l) => (
        <g key={l.id}>
          <line x1="40" x2="520" y1={l.y} y2={l.y} stroke={PAPER} strokeOpacity="0.14" strokeDasharray="3 7" />
          <path d={`M522 ${l.y} l8 -7 h20 v14 h-20 z`} fill="none" stroke={PAPER} strokeOpacity="0.55" />
          <text x="540" y={l.y + 4} textAnchor="middle" fontSize="9" fontWeight="600" fill={PAPER} fillOpacity="0.8">
            {l.id}
          </text>
        </g>
      ))}

      {/* ground floor glazing */}
      <rect x="90" y="526" width="360" height="94" fill="#172329" />
      {mullions(90, 450, 526, 620)}
      {/* level 2 glazing, shorter span */}
      <rect x="90" y="366" width="240" height="148" fill="#172329" />
      {mullions(90, 330, 366, 514)}
      {/* upper solid volume with slot windows */}
      <rect x="210" y="206" width="240" height="148" fill="#EDEBE4" />
      {[246, 294, 342, 390].map((x) => (
        <rect key={x} x={x} y="232" width="12" height="96" fill="#080F12" />
      ))}

      {/* slabs */}
      <rect x="170" y="194" width="320" height="12" fill={PAPER} />
      <rect x="60" y="354" width="440" height="12" fill={PAPER} />
      <rect x="70" y="514" width="400" height="12" fill={PAPER} />

      {/* columns */}
      {axes.map((a) => (
        <rect key={a.id} x={a.x - 3} y="526" width="6" height="94" fill={PAPER} />
      ))}
      {[90, 210, 330].map((x) => (
        <rect key={x} x={x - 3} y="366" width="6" height="148" fill={PAPER} />
      ))}

      {/* highlighted diagonal brace */}
      <line x1="213" y1="369" x2="327" y2="511" stroke={LIME} strokeWidth="3" />
      <circle cx="213" cy="369" r="5" fill={LIME} />
      <circle cx="327" cy="511" r="5" fill={LIME} />

      {/* ground and hatching */}
      <line x1="40" x2="520" y1="620" y2="620" stroke={PAPER} strokeWidth="2" />
      {Array.from({ length: 24 }).map((_, i) => (
        <line key={i} x1={44 + i * 20} y1="620" x2={34 + i * 20} y2="634" stroke={PAPER} strokeOpacity="0.35" />
      ))}

      {/* bay dimension line */}
      <g stroke={PAPER} strokeOpacity="0.55">
        <line x1="90" x2="450" y1="676" y2="676" />
        {axes.map((a) => (
          <line key={a.id} x1={a.x} x2={a.x} y1="669" y2="683" />
        ))}
      </g>
      <text x="270" y="700" textAnchor="middle" fontSize="10" fill={PAPER} fillOpacity="0.6">
        Typical bay grid
      </text>
    </svg>
  );
}
