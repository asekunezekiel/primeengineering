const P = "#FAF9F6";
const L = "#D7FF4F";

/** Schematic wall-to-foundation connection. Illustration only. */
export function SampleDetail() {
  return (
    <svg viewBox="0 0 480 360" role="img" aria-labelledby="sd-t" className="h-full w-full" xmlns="http://www.w3.org/2000/svg">
      <title id="sd-t">Schematic wall-to-foundation connection with footing, sill plate, studs and an anchor bolt. Sample graphic.</title>
      <rect width="480" height="360" fill="#0F191D" />
      <defs>
        <pattern id="sd-hatch" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <line x1="0" y1="0" x2="0" y2="8" stroke={P} strokeOpacity="0.3" />
        </pattern>
      </defs>
      {/* concrete footing and stem */}
      <path d="M110 330 V270 H170 V210 H250 V270 H310 V330 Z" fill="url(#sd-hatch)" stroke={P} strokeWidth="2" />
      {/* sill plate */}
      <rect x="160" y="190" width="100" height="20" fill="none" stroke={P} strokeWidth="2" />
      {/* studs */}
      <rect x="170" y="60" width="16" height="130" fill="none" stroke={P} strokeWidth="2" />
      <rect x="234" y="60" width="16" height="130" fill="none" stroke={P} strokeWidth="2" />
      <line x1="170" y1="60" x2="250" y2="60" stroke={P} strokeWidth="2" />
      {/* anchor bolt */}
      <line x1="210" y1="180" x2="210" y2="262" stroke={L} strokeWidth="4" />
      <path d="M210 262 h-16" stroke={L} strokeWidth="4" />
      <rect x="199" y="176" width="22" height="6" fill={L} />
      {/* callouts */}
      <g stroke={P} strokeOpacity="0.6" fill="none">
        <path d="M221 179 H340 M260 200 H340 M310 300 H340" />
      </g>
      <text x="348" y="183" fontSize="12" fontWeight="600" fill={L}>Anchor bolt</text>
      <text x="348" y="204" fontSize="12" fill={P} fillOpacity="0.85">Sill plate</text>
      <text x="348" y="304" fontSize="12" fill={P} fillOpacity="0.85">Footing</text>
    </svg>
  );
}
