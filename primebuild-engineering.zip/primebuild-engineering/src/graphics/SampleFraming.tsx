const P = "#FAF9F6";
const L = "#D7FF4F";

/** Schematic floor framing plan. Illustration only. */
export function SampleFraming() {
  const joists = Array.from({ length: 15 }, (_, i) => 70 + i * 24);
  return (
    <svg viewBox="0 0 480 360" role="img" aria-labelledby="sf-t" className="h-full w-full" xmlns="http://www.w3.org/2000/svg">
      <title id="sf-t">Schematic floor framing plan with parallel joists, two beams and posts. Sample graphic.</title>
      <rect width="480" height="360" fill="#0F191D" />
      <rect x="54" y="48" width="372" height="236" fill="none" stroke={P} strokeOpacity="0.7" strokeWidth="2" />
      {joists.map((x) => (
        <line key={x} x1={x} x2={x} y1="50" y2="282" stroke={P} strokeOpacity="0.28" />
      ))}
      <line x1="54" x2="426" y1="166" y2="166" stroke={L} strokeWidth="6" />
      <line x1="54" x2="426" y1="283" y2="283" stroke={P} strokeWidth="5" />
      {[54, 240, 426].map((x) => (
        <rect key={x} x={x - 7} y="159" width="14" height="14" fill="#0F191D" stroke={P} strokeWidth="2" />
      ))}
      <text x="250" y="152" fontSize="12" fontWeight="600" fill={L}>B1</text>
      <text x="250" y="302" fontSize="12" fill={P} fillOpacity="0.8">B2</text>
      <text x="64" y="188" fontSize="11" fill={P} fillOpacity="0.8">P1</text>
      <text x="250" y="188" fontSize="11" fill={P} fillOpacity="0.8">P2</text>
      <g stroke={P} strokeOpacity="0.55">
        <line x1="54" x2="426" y1="326" y2="326" />
        <line x1="54" x2="54" y1="319" y2="333" />
        <line x1="426" x2="426" y1="319" y2="333" />
      </g>
      <text x="240" y="346" textAnchor="middle" fontSize="10" fill={P} fillOpacity="0.6">Span</text>
    </svg>
  );
}
