import { z } from "zod";

/**
 * Single source of truth for the inquiry form.
 * Imported by the React form (client validation) and by api/inquiry.ts (server validation).
 */

export const US_STATES = [
  ["AL", "Alabama"], ["AK", "Alaska"], ["AZ", "Arizona"], ["AR", "Arkansas"], ["CA", "California"],
  ["CO", "Colorado"], ["CT", "Connecticut"], ["DE", "Delaware"], ["DC", "District of Columbia"],
  ["FL", "Florida"], ["GA", "Georgia"], ["HI", "Hawaii"], ["ID", "Idaho"], ["IL", "Illinois"],
  ["IN", "Indiana"], ["IA", "Iowa"], ["KS", "Kansas"], ["KY", "Kentucky"], ["LA", "Louisiana"],
  ["ME", "Maine"], ["MD", "Maryland"], ["MA", "Massachusetts"], ["MI", "Michigan"], ["MN", "Minnesota"],
  ["MS", "Mississippi"], ["MO", "Missouri"], ["MT", "Montana"], ["NE", "Nebraska"], ["NV", "Nevada"],
  ["NH", "New Hampshire"], ["NJ", "New Jersey"], ["NM", "New Mexico"], ["NY", "New York"],
  ["NC", "North Carolina"], ["ND", "North Dakota"], ["OH", "Ohio"], ["OK", "Oklahoma"], ["OR", "Oregon"],
  ["PA", "Pennsylvania"], ["RI", "Rhode Island"], ["SC", "South Carolina"], ["SD", "South Dakota"],
  ["TN", "Tennessee"], ["TX", "Texas"], ["UT", "Utah"], ["VT", "Vermont"], ["VA", "Virginia"],
  ["WA", "Washington"], ["WV", "West Virginia"], ["WI", "Wisconsin"], ["WY", "Wyoming"],
] as const;

export const STATE_CODES = US_STATES.map(([code]) => code) as unknown as [string, ...string[]];

export const PROJECT_TYPES = [
  { value: "adu", label: "ADU or guest house" },
  { value: "garage-conversion", label: "Garage conversion" },
  { value: "addition", label: "Addition or remodel" },
  { value: "new-home", label: "New single-family home" },
  { value: "light-commercial", label: "Light-commercial or tenant improvement" },
  { value: "site-work", label: "Site work, grading or drainage" },
  { value: "mechanical-energy", label: "Mechanical or energy compliance only" },
  { value: "plan-check", label: "Plan-check corrections on an existing set" },
  { value: "other", label: "Something else" },
] as const;

export const SERVICES = [
  { value: "structural", label: "Structural engineering" },
  { value: "civil", label: "Civil and site engineering" },
  { value: "permit-plans", label: "Building and permit plans" },
  { value: "mep-energy", label: "MEP and energy compliance" },
  { value: "not-sure", label: "Not sure yet" },
] as const;

export const TIMELINES = [
  { value: "asap", label: "As soon as possible" },
  { value: "2-4-weeks", label: "Within 2 to 4 weeks" },
  { value: "1-3-months", label: "Within 1 to 3 months" },
  { value: "planning", label: "Still planning, no date yet" },
] as const;

const projectTypeValues = PROJECT_TYPES.map((p) => p.value) as unknown as [string, ...string[]];
const serviceValues = SERVICES.map((s) => s.value) as unknown as [string, ...string[]];
const timelineValues = TIMELINES.map((t) => t.value) as unknown as [string, ...string[]];

const singleLine = (max: number) =>
  z
    .string()
    .trim()
    .max(max, `Keep this under ${max} characters.`)
    .refine((v) => !/[\r\n]/.test(v), "Use a single line.");

export const inquirySchema = z.object({
  name: singleLine(100).refine((v) => v.length >= 2, "Enter your name."),
  email: z
    .string()
    .trim()
    .max(200, "That email address is too long.")
    .email("Enter a valid email address, like name@example.com."),
  company: singleLine(120).optional().default(""),
  city: singleLine(100).refine((v) => v.length >= 2, "Enter the city or county of the project."),
  state: z.enum(STATE_CODES, { errorMap: () => ({ message: "Choose the project state." }) }),
  projectType: z.enum(projectTypeValues, {
    errorMap: () => ({ message: "Choose the closest project type." }),
  }),
  services: z
    .array(z.enum(serviceValues))
    .min(1, "Choose at least one service, or pick “Not sure yet”.")
    .max(serviceValues.length),
  description: z
    .string()
    .trim()
    .min(30, "Add a few more details. At least 30 characters helps us review your project.")
    .max(4000, "Keep the description under 4,000 characters."),
  timeline: z.enum(timelineValues, { errorMap: () => ({ message: "Choose a target timeline." }) }),
  consent: z.literal(true, {
    errorMap: () => ({ message: "Please confirm you agree to us using these details to reply." }),
  }),
  // Spam signals
  website: z.string().max(500).optional().default(""), // honeypot, must stay empty
  startedAt: z.number().int().optional(),
  turnstileToken: z.string().max(4096).optional().default(""),
});

export type InquiryInput = z.input<typeof inquirySchema>;
export type InquiryData = z.output<typeof inquirySchema>;
export type FieldErrors = Partial<Record<keyof InquiryData, string>>;

export function flattenErrors(error: z.ZodError): FieldErrors {
  const out: FieldErrors = {};
  for (const issue of error.issues) {
    const key = issue.path[0] as keyof InquiryData | undefined;
    if (key && !out[key]) out[key] = issue.message;
  }
  return out;
}

export const labelFor = {
  projectType: (v: string) => PROJECT_TYPES.find((p) => p.value === v)?.label ?? v,
  service: (v: string) => SERVICES.find((s) => s.value === v)?.label ?? v,
  timeline: (v: string) => TIMELINES.find((t) => t.value === v)?.label ?? v,
  state: (v: string) => US_STATES.find(([c]) => c === v)?.[1] ?? v,
};
