export const SITE = {
  name: "PrimeBuild Engineering",
  email: (import.meta.env.VITE_CONTACT_EMAIL as string | undefined) || "proengineers.team@gmail.com",
  turnstileSiteKey: (import.meta.env.VITE_TURNSTILE_SITE_KEY as string | undefined) || "",
  brandStatement: "Clear scope. Coordinated documentation. A practical path forward.",
  licensingNotice:
    "Engineering stamps, signed calculations, and sealed plans depend on project scope, jurisdiction, applicable licensing, and confirmation by an appropriately licensed professional. Services are not available in every state, and permit approval or code acceptance cannot be guaranteed.",
} as const;

export const ROUTES = {
  home: "/",
  contact: "/contact",
} as const;

export const NAV = [
  { label: "Services", hash: "services" },
  { label: "Project types", hash: "project-types" },
  { label: "Deliverables", hash: "deliverables" },
  { label: "Work samples", hash: "work" },
  { label: "Process", hash: "process" },
  { label: "FAQ", hash: "faq" },
] as const;

/**
 * Optional real hero photograph. Leave null to use the built-in illustration.
 * Only use an image you own or are licensed to use. Place it in /public/images.
 */
export const HERO_PHOTO: { src: string; alt: string; width: number; height: number } | null = null;
