import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, within, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter } from "react-router-dom";
import App from "../App";

function renderAt(path: string) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <App />
    </MemoryRouter>,
  );
}

describe("homepage", () => {
  it("renders every required section in order with one h1", () => {
    const { container } = renderAt("/");
    expect(screen.getAllByRole("heading", { level: 1 })).toHaveLength(1);
    expect(screen.getByRole("heading", { level: 1 })).toHaveTextContent("Engineering for what’s next.");

    const order = [
      "hero-title",
      "needs-title",
      "services-title",
      "types-title",
      "deliverables-title",
      "work-title",
      "why-title",
      "process-title",
      "faq-title",
      "cta-title",
    ];
    const positions = order.map((id) => {
      const el = container.querySelector(`#${id}`);
      expect(el, id).not.toBeNull();
      return Array.from(container.querySelectorAll("*")).indexOf(el!);
    });
    expect([...positions].sort((a, b) => a - b)).toEqual(positions);
    expect(screen.getByRole("banner")).toBeInTheDocument();
    expect(screen.getByRole("contentinfo")).toBeInTheDocument();
  });

  it("labels sample graphics and never claims them as projects", () => {
    renderAt("/");
    expect(screen.getAllByText("Sample graphic").length).toBe(3);
    expect(screen.queryByText("Project drawing")).toBeNull();
  });

  it("does not guarantee approval anywhere in the copy", () => {
    const { container } = renderAt("/");
    expect(container.textContent).not.toMatch(/guaranteed? (permit|approval)/i);
  });

  it("switches audience tabs with the keyboard", async () => {
    const user = userEvent.setup();
    renderAt("/");
    const tabs = screen.getAllByRole("tab");
    expect(tabs[0]).toHaveAttribute("aria-selected", "true");
    tabs[0]!.focus();
    await user.keyboard("{ArrowDown}");
    expect(tabs[1]).toHaveAttribute("aria-selected", "true");
    expect(tabs[1]).toHaveFocus();
    expect(screen.getByRole("tabpanel")).toHaveAttribute("aria-labelledby", tabs[1]!.id);
  });

  it("toggles FAQ items", async () => {
    const user = userEvent.setup();
    renderAt("/");
    const btn = screen.getByRole("button", { name: /Which states do you work in/i });
    expect(btn).toHaveAttribute("aria-expanded", "false");
    await user.click(btn);
    expect(btn).toHaveAttribute("aria-expanded", "true");
  });
});

describe("contact form", () => {
  beforeEach(() => vi.restoreAllMocks());

  async function fillValid(user: ReturnType<typeof userEvent.setup>) {
    await user.type(screen.getByLabelText("Name"), "Alex Rivera");
    await user.type(screen.getByLabelText("Email"), "alex@example.com");
    await user.type(screen.getByLabelText(/Project city or county/i), "Sacramento");
    await user.selectOptions(screen.getByLabelText("State"), "CA");
    await user.selectOptions(screen.getByLabelText("Project type"), "adu");
    await user.click(screen.getByLabelText("Structural engineering"));
    await user.type(
      screen.getByLabelText(/Project description/i),
      "Detached ADU of about 800 square feet that needs structural calculations.",
    );
    await user.selectOptions(screen.getByLabelText("Target timeline"), "2-4-weeks");
    await user.click(screen.getByLabelText(/I agree that PrimeBuild/i));
  }

  it("shows an error summary and field errors for an empty submit, without calling the network", async () => {
    const fetchSpy = vi.spyOn(globalThis, "fetch");
    const user = userEvent.setup();
    renderAt("/contact");
    await user.click(screen.getByRole("button", { name: "Send inquiry" }));
    const alert = await screen.findByRole("alert");
    expect(within(alert).getByText(/Please fix \d+ fields/)).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toHaveAttribute("aria-invalid", "true");
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("prefills services and project type from the query string", () => {
    renderAt("/contact?services=structural,mep-energy&type=adu");
    expect(screen.getByLabelText("Structural engineering")).toBeChecked();
    expect(screen.getByLabelText("MEP and energy compliance")).toBeChecked();
    expect(screen.getByLabelText("Project type")).toHaveValue("adu");
  });

  it("shows success only after the server confirms delivery", async () => {
    const fetchSpy = vi.spyOn(globalThis, "fetch").mockResolvedValue(
      new Response(JSON.stringify({ ok: true }), { status: 200 }),
    );
    const user = userEvent.setup();
    renderAt("/contact");
    await fillValid(user);
    await user.click(screen.getByRole("button", { name: "Send inquiry" }));
    expect(await screen.findByText("Your inquiry was sent.")).toBeInTheDocument();
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    const body = JSON.parse((fetchSpy.mock.calls[0]![1] as RequestInit).body as string);
    expect(body.email).toBe("alex@example.com");
    expect(body.services).toEqual(["structural"]);
  });

  it("shows a failure, not success, when the server is not configured", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue(
      new Response(JSON.stringify({ ok: false, code: "not_configured" }), { status: 503 }),
    );
    const user = userEvent.setup();
    renderAt("/contact");
    await fillValid(user);
    await user.click(screen.getByRole("button", { name: "Send inquiry" }));
    expect(await screen.findByText("Your inquiry was not sent.")).toBeInTheDocument();
    expect(screen.queryByText("Your inquiry was sent.")).toBeNull();
    const alert = await screen.findByRole("alert");
    await waitFor(() =>
      expect(within(alert).getByRole("link", { name: /proengineers\.team@gmail\.com/ })).toBeInTheDocument(),
    );
  });

  it("shows a failure when the network request throws", async () => {
    vi.spyOn(globalThis, "fetch").mockRejectedValue(new TypeError("offline"));
    const user = userEvent.setup();
    renderAt("/contact");
    await fillValid(user);
    await user.click(screen.getByRole("button", { name: "Send inquiry" }));
    expect(await screen.findByText("Your inquiry was not sent.")).toBeInTheDocument();
  });
});
