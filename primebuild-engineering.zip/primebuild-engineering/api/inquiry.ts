import { inquirySchema, flattenErrors, labelFor, type InquiryData } from "../src/lib/inquirySchema.js";

/**
 * POST /api/inquiry
 * Validates a project inquiry and delivers it by email through Resend.
 * Returns { ok: true } only after the email provider has accepted the message.
 *
 * Required env: RESEND_API_KEY, INQUIRY_FROM_EMAIL
 * Optional env: INQUIRY_TO_EMAIL, TURNSTILE_SECRET_KEY, ALLOWED_ORIGINS
 */

// Minimal request/response shapes so the project does not need @vercel/node at build time.
type Req = {
  method?: string;
  headers: Record<string, string | string[] | undefined>;
  body?: unknown;
  socket?: { remoteAddress?: string };
};
type Res = {
  status(code: number): Res;
  json(body: unknown): void;
  setHeader(name: string, value: string): void;
};

const DEFAULT_TO = "proengineers.team@gmail.com";
const MIN_FILL_MS = 1500;
const RATE_WINDOW_MS = 10 * 60 * 1000;
const RATE_MAX = 5;

// Best-effort limiter. Serverless instances do not share memory, so this only slows
// down simple bursts. Turnstile is the real spam control.
const hits = new Map<string, number[]>();

function header(req: Req, name: string): string {
  const v = req.headers[name];
  return (Array.isArray(v) ? v[0] : v) ?? "";
}

function clientIp(req: Req): string {
  return header(req, "x-forwarded-for").split(",")[0]?.trim() || req.socket?.remoteAddress || "unknown";
}

function rateLimited(ip: string, now: number): boolean {
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < RATE_WINDOW_MS);
  recent.push(now);
  hits.set(ip, recent);
  if (hits.size > 5000) hits.clear();
  return recent.length > RATE_MAX;
}

function originAllowed(req: Req): boolean {
  const origin = header(req, "origin");
  if (!origin) return true; // non-browser or same-origin GET-style request
  const allowed = (process.env.ALLOWED_ORIGINS ?? "")
    .split(",")
    .map((s) => s.trim().replace(/\/$/, ""))
    .filter(Boolean);
  if (allowed.length > 0) return allowed.includes(origin.replace(/\/$/, ""));
  try {
    return new URL(origin).host === header(req, "host");
  } catch {
    return false;
  }
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function buildEmail(d: InquiryData) {
  const services = d.services.map(labelFor.service).join(", ");
  const rows: [string, string][] = [
    ["Name", d.name],
    ["Email", d.email],
    ["Company", d.company || "Not provided"],
    ["Project location", `${d.city}, ${labelFor.state(d.state)}`],
    ["Project type", labelFor.projectType(d.projectType)],
    ["Services needed", services],
    ["Target timeline", labelFor.timeline(d.timeline)],
  ];

  const text = [
    "New project inquiry from the PrimeBuild Engineering website",
    "",
    ...rows.map(([k, v]) => `${k}: ${v}`),
    "",
    "Project description:",
    d.description,
  ].join("\n");

  const html = `<!doctype html><html><body style="margin:0;padding:24px;background:#faf9f6;font-family:Inter,Arial,sans-serif;color:#080f12">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:640px;margin:0 auto">
<tr><td style="padding-bottom:16px;font-size:13px;letter-spacing:.08em;color:#4b5552">PRIMEBUILD ENGINEERING / NEW PROJECT INQUIRY</td></tr>
${rows
  .map(
    ([k, v]) =>
      `<tr><td style="padding:10px 0;border-top:1px solid #dcdad2"><div style="font-size:12px;color:#4b5552">${escapeHtml(k)}</div><div style="font-size:16px">${escapeHtml(v)}</div></td></tr>`,
  )
  .join("\n")}
<tr><td style="padding:10px 0;border-top:1px solid #dcdad2"><div style="font-size:12px;color:#4b5552">Project description</div><div style="font-size:16px;line-height:1.55;white-space:pre-wrap">${escapeHtml(d.description)}</div></td></tr>
</table></body></html>`;

  const subject = `New project inquiry: ${labelFor.projectType(d.projectType)} (${d.state})`.replace(/[\r\n]+/g, " ");
  return { subject, text, html };
}

async function verifyTurnstile(token: string, ip: string, secret: string): Promise<boolean> {
  try {
    const body = new URLSearchParams({ secret, response: token });
    if (ip !== "unknown") body.set("remoteip", ip);
    const r = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      body,
      signal: AbortSignal.timeout(8000),
    });
    const data = (await r.json()) as { success?: boolean };
    return data.success === true;
  } catch (err) {
    console.error("[inquiry] turnstile verification error", err instanceof Error ? err.message : err);
    return false;
  }
}

export default async function handler(req: Req, res: Res) {
  res.setHeader("Cache-Control", "no-store");

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ ok: false, code: "method_not_allowed", message: "Use POST." });
  }
  if (!originAllowed(req)) {
    return res.status(403).json({ ok: false, code: "forbidden", message: "This origin is not allowed." });
  }

  const now = Date.now();
  const ip = clientIp(req);
  if (rateLimited(ip, now)) {
    return res.status(429).json({
      ok: false,
      code: "rate_limited",
      message: "Too many submissions from this connection. Please wait a few minutes and try again.",
    });
  }

  let payload: unknown = req.body;
  if (typeof payload === "string") {
    try {
      payload = JSON.parse(payload);
    } catch {
      return res.status(400).json({ ok: false, code: "bad_json", message: "The request could not be read." });
    }
  }
  if (!payload || typeof payload !== "object") {
    return res.status(400).json({ ok: false, code: "bad_json", message: "The request could not be read." });
  }

  const parsed = inquirySchema.safeParse(payload);
  if (!parsed.success) {
    return res.status(400).json({
      ok: false,
      code: "validation",
      message: "Some fields need attention.",
      errors: flattenErrors(parsed.error),
    });
  }
  const data = parsed.data;

  // Honeypot: real people never see or fill this field. Drop silently.
  if (data.website) {
    console.warn("[inquiry] honeypot triggered, dropping submission");
    return res.status(200).json({ ok: true });
  }
  if (data.startedAt && now - data.startedAt < MIN_FILL_MS) {
    return res.status(400).json({
      ok: false,
      code: "too_fast",
      message: "That was very quick. Please review your details and submit again.",
    });
  }

  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.INQUIRY_FROM_EMAIL;
  if (!apiKey || !from) {
    console.error("[inquiry] RESEND_API_KEY or INQUIRY_FROM_EMAIL is not set");
    return res.status(503).json({
      ok: false,
      code: "not_configured",
      message: "Online submissions are not available yet.",
    });
  }

  const turnstileSecret = process.env.TURNSTILE_SECRET_KEY;
  if (turnstileSecret) {
    if (!data.turnstileToken || !(await verifyTurnstile(data.turnstileToken, ip, turnstileSecret))) {
      return res.status(400).json({
        ok: false,
        code: "captcha",
        message: "We could not verify that you are human. Please try the check again.",
      });
    }
  }

  const to = (process.env.INQUIRY_TO_EMAIL || DEFAULT_TO).split(",").map((s) => s.trim()).filter(Boolean);
  const { subject, text, html } = buildEmail(data);

  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to, reply_to: data.email, subject, text, html }),
      signal: AbortSignal.timeout(10000),
    });
    if (!r.ok) {
      const detail = await r.text().catch(() => "");
      console.error(`[inquiry] Resend rejected the message (${r.status}): ${detail.slice(0, 300)}`);
      return res.status(502).json({
        ok: false,
        code: "delivery_failed",
        message: "We could not deliver your inquiry.",
      });
    }
    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error("[inquiry] delivery error", err instanceof Error ? err.message : err);
    return res.status(502).json({
      ok: false,
      code: "delivery_failed",
      message: "We could not deliver your inquiry.",
    });
  }
}
